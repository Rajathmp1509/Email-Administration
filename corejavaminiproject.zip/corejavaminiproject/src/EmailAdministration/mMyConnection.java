package EmailAdministration;

import java.sql.Connection;
import java.sql.DriverManager;

public class mMyConnection {
    private static Connection con;

    public static Connection getConnection() {
        try {
            if (con == null || con.isClosed()) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/email_admin_db", "root", "123456789");
            }
        } catch (Exception e) {
            System.out.println("Database connection failed: " + e.getMessage());
        }
        return con;
    }
}
