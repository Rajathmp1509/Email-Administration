package EmailAdministration;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmailDAO dao = new EmailDAO();
        int choice;

        System.out.println("====== EMAIL ADMINISTRATION SYSTEM ======");
        
        do {
            System.out.println("\n========== MENU ==========");
            System.out.println("1. Create Employee Table");
            System.out.println("2. Add New Employee");
            System.out.println("3. View All Employees");
            System.out.println("4. Update Employee Details");
            System.out.println("5. Delete Employee");
            System.out.println("6. Search Employee by ID");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    dao.createTable();
                    break;

                case 2:
                    sc.nextLine(); // clear buffer
                    System.out.print("Enter Employee Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Department: ");
                    String dept = sc.nextLine();
                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();
                    System.out.print("Enter Password: ");
                    String pass = sc.nextLine();
                    dao.addEmployee(new EmailAccount(name, dept, email, pass));
                    break;

                case 3:
                    List<EmailAccount> list = dao.getAllEmployees();
                    System.out.println("\nID   NAME            DEPARTMENT     EMAIL                     PASSWORD");
                    System.out.println("--------------------------------------------------------------------------");
                    for (EmailAccount e : list) System.out.println(e);
                    break;

                case 4:
                    System.out.print("Enter Employee ID to Update: ");
                    int uid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Name: ");
                    String n = sc.nextLine();
                    System.out.print("Enter New Department: ");
                    String d = sc.nextLine();
                    System.out.print("Enter New Email: ");
                    String em = sc.nextLine();
                    System.out.print("Enter New Password: ");
                    String p = sc.nextLine();
                    dao.updateEmployee(uid, n, d, em, p);
                    break;

                case 5:
                    System.out.print("Enter Employee ID to Delete: ");
                    int did = sc.nextInt();
                    dao.deleteEmployee(did);
                    break;

                case 6:
                    System.out.print("Enter Employee ID to Search: ");
                    int sid = sc.nextInt();
                    EmailAccount emp = dao.searchById(sid);
                    if (emp != null)
                        System.out.println("Found: " + emp);
                    else
                        System.out.println("❌ Employee not found.");
                    break;

                case 7:
                    System.out.println("👋 Exiting... Thank you!");
                    break;

                default:
                    System.out.println("❌ Invalid choice. Please try again!");
            }
        } while (choice != 7);

        sc.close();
    }
}
