package EmailAdministration;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmailDAO {

    // Create table
    public void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS employees (" +
                     "id INT AUTO_INCREMENT PRIMARY KEY, " +
                     "name VARCHAR(100), " +
                     "department VARCHAR(50), " +
                     "email VARCHAR(100) UNIQUE, " +
                     "password VARCHAR(100))";
        try (Connection con = mMyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.executeUpdate();
            System.out.println("✅ Table 'employees' created or already exists.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Add new email record
    public void addEmployee(EmailAccount emp) {
        String sql = "INSERT INTO employees (name, department, email, password) VALUES (?, ?, ?, ?)";
        try (Connection con = mMyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getDepartment());
            ps.setString(3, emp.getEmail());
            ps.setString(4, emp.getPassword());
            ps.executeUpdate();
            System.out.println("✅ Employee added successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // View all
    public List<EmailAccount> getAllEmployees() {
        List<EmailAccount> list = new ArrayList<>();
        String sql = "SELECT * FROM employees";
        try (Connection con = mMyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new EmailAccount(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getString("email"),
                        rs.getString("password")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Update employee record
    public void updateEmployee(int id, String name, String department, String email, String password) {
        String sql = "UPDATE employees SET name=?, department=?, email=?, password=? WHERE id=?";
        try (Connection con = mMyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, department);
            ps.setString(3, email);
            ps.setString(4, password);
            ps.setInt(5, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("✅ Employee details updated successfully.");
            else
                System.out.println("❌ Employee not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete employee
    public void deleteEmployee(int id) {
        String sql = "DELETE FROM employees WHERE id=?";
        try (Connection con = mMyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            if (rows > 0)
                System.out.println("✅ Employee deleted successfully.");
            else
                System.out.println("❌ Employee not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Search employee by ID
    public EmailAccount searchById(int id) {
        String sql = "SELECT * FROM employees WHERE id=?";
        try (Connection con = mMyConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new EmailAccount(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getString("email"),
                        rs.getString("password")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
