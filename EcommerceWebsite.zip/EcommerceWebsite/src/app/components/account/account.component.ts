import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-account',
  standalone:false,
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent {}
