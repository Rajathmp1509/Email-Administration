import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private baseUrl = 'http://localhost:8084/cart/api';

  constructor(private http: HttpClient) {}

  // ✅ Add to cart
  addToCart(customerId: number, productId: number): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/add/${customerId}/${productId}`,
      {}
    );
  }

  // ✅ Get cart items
  getCartItems(customerId: number): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.baseUrl}/${customerId}`
    );
  }

  // ✅ Remove single item
  removeItem(cartItemId: number): Observable<any> {
    return this.http.delete(
      `${this.baseUrl}/remove/${cartItemId}`
    );
  }

  // ✅ Clear cart
  clearCart(customerId: number): Observable<any> {
    return this.http.delete(
      `${this.baseUrl}/clear/${customerId}`
    );
  }
}
